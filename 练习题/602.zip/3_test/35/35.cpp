#include<iostream>
#include<string>
using namespace std;
int main()
{
    char cont;
    cont='y';
    string s,result;
    cout<<"第一个字符串："<<endl;
    while(cin>>s)
    {
    
    }
}
