
#include<iostream>
#include<string>

using namespace std;
int main()
{
    string world;
    cout<<"please enter the worlds,don't cin space"<<endl;
    while(cin>>world)
    {
        cout <<world<<endl;
    }
    return 0;
}
