
int ff(int a,int b=0,int c=0);
char * init(int ht=24,int wd,char bckgrnd);
//第二个是错误的，缺省参数只能从左往右边缺省
