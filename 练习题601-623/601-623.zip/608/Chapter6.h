#ifndef CHAPTER6_H_INCLUDED
#define CHAPTER6_H_INCLUDED 

int fact(int);//缺省参数
double myAbs(double);
double myAbs22(double);

#endif
