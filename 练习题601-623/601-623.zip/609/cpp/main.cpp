#include "Chapter6.h"
using namespace std;
int main()
{
    int num=0;
    cout<<"请输入一个数字"<<endl;
    cin>>num;
    cout<<num<<"的阶乘是："<<fact(num)<<endl;
    return 0;
}
