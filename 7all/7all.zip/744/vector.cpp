#include<iostream>
#include<vector>
#include<string>
using namespace std;
int main()
{
    vector<string> a(10);
    for(auto x:a)
        cout<< x<< ' ';
    cout<<endl;

}
