#include<iostream>
using namespace std;
class Person
{
    private:
        string Str_Name_;
        string Str_Address_;
};
