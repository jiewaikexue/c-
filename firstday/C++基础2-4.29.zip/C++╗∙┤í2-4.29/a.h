#pragma once
inline int sub(int a, int b)
{
	return a - b;
}
