#include<iostream>

int main()
{
    std::cout<<5+10*20/2<<std::endl;
    return 0;

}
