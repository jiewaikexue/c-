#include<iostream>
#include<vector>
using std::cout;
using std::endl;
using std::vector;
int main()
{
cout<<12/3*4+5*15+24%4/2<<endl;
    return 0;
}
