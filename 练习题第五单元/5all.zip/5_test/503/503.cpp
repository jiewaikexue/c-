#include<iostream>

int main()
{
//
//   //原来的写法
//  while(val<=10)
//  {
//      sum+=val;
//      ++val;
//  }
//

  while(val<=10)

    sum+=val,++val;



}
