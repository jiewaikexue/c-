#include<iostream>
#include<vector>
#include<string>


using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;
int main()
{

    vector<int>v1;
    vector<int>v4;
    for(int i=10;i>1;i--)
    {
        v1.push_back(42);

    }
    vector<int>v2={42,42,42,42,42,42,42,42,42};
    vector<int>v3{42,42,42,42,42,42,42,42,42};

    return 0;
}
